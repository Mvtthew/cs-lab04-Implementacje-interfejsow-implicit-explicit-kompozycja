﻿using System;

namespace BezKlasyCopier
{
	class Program
	{
		static void Test(string[] args)
		{
			Console.WriteLine("Hello World!");
		}
	}
}
